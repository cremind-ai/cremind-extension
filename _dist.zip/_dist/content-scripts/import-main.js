!function(){const t=JSON.parse('"content-scripts/main.js"');import(chrome.runtime.getURL(t));}();
